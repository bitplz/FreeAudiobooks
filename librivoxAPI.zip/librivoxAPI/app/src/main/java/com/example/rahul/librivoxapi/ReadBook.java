package com.example.rahul.librivoxapi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.webkit.WebView;
import android.widget.TextView;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class ReadBook extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_book);

        webView = (WebView) findViewById(R.id.webView);

        ProgressDialog progressDialog = new ProgressDialog(ReadBook.this);
        progressDialog.setTitle("Loading");
        progressDialog.setMessage("Getting Content...");
        progressDialog.show();

        Intent intent = getIntent();
        String textSource = intent.getStringExtra("url_text_source");
        String title = intent.getStringExtra("title");

        getSupportActionBar().setTitle(title);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(textSource);
        progressDialog.dismiss();

    }
}

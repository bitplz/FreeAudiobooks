package com.example.rahul.librivoxapi;

import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;
import android.widget.SearchView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener, productAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private productAdapter mProductAdapter;
    private ArrayList<Product> productItemList;
    private RequestQueue mRequestQueue;
    private String searchText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setHasFixedSize(true);
        productItemList = new ArrayList<>();
        mProductAdapter = new productAdapter(this, productItemList);
        recyclerView.setAdapter(mProductAdapter);
        mRequestQueue = Volley.newRequestQueue(this);

        parseJson();

    }

    public void parseJson() {
        productItemList.clear();

        String url = "https://librivox.org/api/feed/audiobooks/?title=^" + searchText + "&format=json&extended=1";

        final ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Loading Content...");
        progressDialog.show();

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        JSONArray jsonArray = null;
                        try {

                            JSONObject root = new JSONObject();
                            JSONObject book = new JSONObject();
                            root = response.getJSONObject("books");
                            String error = response.optString("books");

                            if (error.isEmpty()){
                                Toast.makeText(MainActivity.this, "Couldn't find the specified book",Toast.LENGTH_LONG).show();
                                progressDialog.dismiss();
                                finish();
                            }

                            Iterator<?> keys = root.keys();

                            while (keys.hasNext()) {
                                String key = (String) keys.next();
                                if (root.get(key) instanceof JSONObject) {
                                    book = root.getJSONObject(key);

                                    String authorName = null, fName, lName;

                                    ////////////Authors/////////////
                                    JSONArray authors = book.getJSONArray("authors");
                                    for (int i = 0; i < authors.length(); i++) {
                                        JSONObject j = authors.getJSONObject(i);
                                        fName = j.getString("first_name");
                                        lName = j.getString("last_name");
                                        authorName = fName + " " + lName;

                                    }
                                    ///////////////////////////////

                                    ////////////Sections/////////////
//                                    JSONArray sections = book.getJSONArray("authors");
//                                    for (int i = 0; i < sections.length(); i++){
//                                        JSONObject sectionsJSONObject = sections.getJSONObject(i);
//                                        fName = sectionsJSONObject.getString("first_name");
//                                        lName = sectionsJSONObject.getString("last_name");
//                                        authorName = fName+" "+lName;
//
//                                    }
                                    ///////////////////////////////

                                    String title = book.getString("title");
                                    String summary = book.getString("description");
                                    String imgUrl = book.getString("url_iarchive");
                                    String url_text_source = book.getString("url_text_source");
                                    String url_text_source_final = "http://www.gutenberg.org/files/" +
                                            url_text_source.substring(url_text_source.lastIndexOf('/') + 1) + "/" + url_text_source.substring(url_text_source.lastIndexOf('/') + 1) + "-h/" +
                                            url_text_source.substring(url_text_source.lastIndexOf('/') + 1) + "-h.htm";
//                                    String url_mp3 = book.getString("url_zip_file");
                                    imgUrl = "https://archive.org/services/img/" + imgUrl.substring(imgUrl.lastIndexOf('/') + 1);

                                    productItemList.add(new Product(title, summary, imgUrl, authorName, url_text_source_final));

                                }
                            }

                            mProductAdapter = new productAdapter(MainActivity.this, productItemList);
                            recyclerView.setAdapter(mProductAdapter);
                            mProductAdapter.setOnIemClickListener(MainActivity.this);
                            progressDialog.dismiss();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_search, menu);
        MenuItem item = menu.findItem(R.id.menu_search);

        SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);
        searchView.setOnQueryTextListener(this);

        return true;
    }

    @Override
    public void onItemClick(int position) {

        Product clickedItem = productItemList.get(position);
        Intent intent = new Intent(MainActivity.this, BookActivity.class);
        intent.putExtra("title", clickedItem.getMtitle());
        intent.putExtra("author", clickedItem.getmAuthor());
        intent.putExtra("summary", clickedItem.getmSummary());
        intent.putExtra("imgUrl", clickedItem.getmImgUrl());
        intent.putExtra("url_text_source", clickedItem.getmUrl_text());
        startActivity(intent);

        Toast.makeText(MainActivity.this, "It Works!| Item-Position: " + position + " | Author :" + clickedItem.getmAuthor(), Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        searchText = query;
        parseJson();
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        newText = newText.toLowerCase();
        ArrayList<Product> newlist = new ArrayList<>();
        for (Product product : productItemList) {
            String name = product.getMtitle().toLowerCase();
            if (name.contains(newText)) {
                newlist.add(product);
            }
        }
        mProductAdapter.setFilter(newlist);

        return false;
    }

}

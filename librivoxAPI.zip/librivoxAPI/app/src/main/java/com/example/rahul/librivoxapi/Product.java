
package com.example.rahul.librivoxapi;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Product {

    private String mImgUrl;
    private String mtitle;
    private String mSummary;
    private String mAuthor;
    private String mUrl_text;

    public Product(String title, String summary, String imgUrl, String author, String url_text) {
        this.mtitle = title;
        this.mImgUrl = imgUrl;
        this.mSummary = summary;
        this.mAuthor = author;
        this.mUrl_text = url_text;
    }

    public String getMtitle() {
        return mtitle;
    }

    public void setMtitle(String mtitle) {
        this.mtitle = mtitle;
    }

    public String getmImgUrl() {
        return mImgUrl;
    }

    public void setmImgUrl(String mImgUrl) {
        this.mImgUrl = mImgUrl;
    }

    public String getmSummary() {
        return mSummary;
    }

    public void setmSummary(String mSummary) {
        this.mSummary = mSummary;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public void setmAuthor(String mAuthor) {
        this.mAuthor = mAuthor;
    }

    public String getmUrl_text() {
        return mUrl_text;
    }

    public void setmUrl_text(String mUrl_text) {
        this.mUrl_text = mUrl_text;
    }
}

package com.example.rahul.librivoxapi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ButtonBarLayout;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.ms.square.android.expandabletextview.ExpandableTextView;
import com.squareup.picasso.Picasso;

public class BookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        ExpandableTextView expandableTextView = (ExpandableTextView) findViewById(R.id.expandable_text_view);
        TextView title = (TextView) findViewById(R.id.bookTitle);
        TextView author = (TextView) findViewById(R.id.authorName);
        Button button = (Button) findViewById(R.id.read_book);

        final Intent intent = getIntent();
        String imgUrl = intent.getStringExtra("imgUrl");
        final String booktitle = intent.getStringExtra("title");
        String authorName = "By: "+intent.getStringExtra("author");
        String summary = intent.getStringExtra("summary");
        final String url_text_source = intent.getStringExtra("url_text_source");

        getSupportActionBar().setTitle(booktitle);

        Picasso.get().load(imgUrl).fit().centerInside().into(imageView);
        title.setText(booktitle);
        author.setText(authorName);
        expandableTextView.setText(Html.fromHtml(summary));

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(BookActivity.this, ReadBook.class);
                intent1.putExtra("url_text_source",url_text_source);
                intent1.putExtra("title", booktitle);
                startActivity(intent1);
            }
        });
    }
}
